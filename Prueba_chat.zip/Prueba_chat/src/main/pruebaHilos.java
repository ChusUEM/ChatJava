package main;

import java.net.ServerSocket;
import java.net.Socket;

public class pruebaHilos {

	public static void main(String[] args) {
		System.out.println("Iniciando nuevo hilo");
		
		try (ServerSocket socketServidor = new ServerSocket(9999)){
			
			System.out.println("Hilo iniciado");
			
			while(true) {
				
				Socket socketHilo = socketServidor.accept();
				System.out.println("Nuevo hilo iniciado con el cliente");
				pruebaServidor hiloServidor = new pruebaServidor(socketHilo);
				hiloServidor.start();
			}
			
		} catch (Exception e){
			System.out.println("El error que ocurrió en el nuevo hilo fue: " + e.getStackTrace());
		}

	}

}
