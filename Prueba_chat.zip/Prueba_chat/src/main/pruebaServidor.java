package main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class pruebaServidor extends Thread {
	
	
	  	// Array de opciones que se le presentan al Cliente
  	private static final String[] OPTIONS = {"1", "2", "3", "4", "5"};
  	// Creamos un mapa de respuestas para cada opción
  	private static final Map<String, String> RESPONSES = new HashMap<>();

  	static {
    RESPONSES.put("1", "OK! Mi comida italiana favorita es la pizza");
    RESPONSES.put("2", "OK! Mi comida italiana favorita son los macarrones");
    RESPONSES.put("3", "OK! Mi comida italiana favorita son los espaguetis");
    RESPONSES.put("4", "OK! Mi comida italiana favorita son los canelones");
    RESPONSES.put("5", "OK! Mi comida italiana favorita es el rabbioli");
  	}


	private Socket socketServidor;
	private PrintWriter salida;
	
	public pruebaServidor (Socket socket) {
		this.socketServidor = socket;
	}
	
	public void run() {
		try {
			BufferedReader entrada = new BufferedReader(new InputStreamReader(socketServidor.getInputStream()));
			boolean salir = false;
			salida = new PrintWriter(socketServidor.getOutputStream(), true);
			salida.println("¡Bienvenido al servidor! Si quiere, continúe con el proceso, en caso contrario escriba: 'salir'");
			String nombre;
			
			while (!salir) {
				nombre = entrada.readLine();
				if (nombre.equals("salir")) {
					salir = true;
					System.out.println("Adiós - Cerramos conexión con el cliente");
				} else {
					System.out.println("El nombre del cliente es: " + nombre);
				}
					// Enviamos al cliente las opciones disponibles
					PrintWriter eleccion = new PrintWriter(socketServidor.getOutputStream(), true);
					eleccion.println("Elige una de las siguientes opciones:");
			        for (String opciones : OPTIONS) {
			        	eleccion.println(opciones);
			        }
			        
				
			        // Lectura de la selección del cliente:
					BufferedReader request = new BufferedReader(new InputStreamReader(socketServidor.getInputStream()));
					String seleccion = request.readLine();

					
			        // Enviamos al cliente la respuesta correspondiente
			        String respuesta = RESPONSES.get(seleccion);
			        salida.println(respuesta);
					System.out.println(nombre + " ha enviado: " + seleccion);
			        
					// Cerramos el socket
			        socketServidor.close();
					
			}
			
		} catch (Exception e) {
				System.out.println("Ocurrió el error: " + e.getStackTrace());
		}
	}

}

