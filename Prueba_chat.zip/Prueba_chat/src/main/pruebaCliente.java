package main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class pruebaCliente {

	public static void main(String[] args) {
		
		try (Socket socketCliente = new Socket("localhost", 9999)) {
			
			BufferedReader entrada = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
			PrintWriter salida = new PrintWriter(socketCliente.getOutputStream(), true);
			
			Scanner escaneado = new Scanner(System.in);
			String entradaUsuario = null;
			String respuesta;
			String nombreCliente = "vacío";
			
			respuesta = entrada.readLine();
			System.out.println(respuesta);
			
			do {
				if (nombreCliente.equals("vacío")) {
					System.out.println("¿Cuál es tu nombre?");
					entradaUsuario = escaneado.nextLine();
					nombreCliente = entradaUsuario;
					salida.println(entradaUsuario);
					if (entradaUsuario.equals("salir")) {
						entrada.close();
						escaneado.close();
						System.out.println("Adiós");
						break;
					}
				} else {

					// Recibimos la solicitud del servidor:
					BufferedReader solicitud = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
					String opciones = solicitud.readLine();
					System.out.println(opciones);
					while ( solicitud.ready()) {
						opciones = solicitud.readLine();
						System.out.println(opciones);
					}
					
					// El cliente escribe su respuesta al servidor:
					Scanner escanear = new Scanner(System.in);
					String escaneado2 = escanear.nextLine();
					System.out.println(nombreCliente + " escribe: " + escaneado2);
					// Se lo envío al servidor:
					PrintWriter out = new PrintWriter(socketCliente.getOutputStream(), true);
					out.println(escaneado2);
					
					
					// Recibimos la respuesta del servidor según nuestra elección:
					BufferedReader eleccion = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
				    String resultado = eleccion.readLine();
				    if (resultado != null) {
				    System.out.println("Ha elegido " + escaneado2 + ", así que: " + resultado);
				    } else {
				    	System.out.println("No se ha recibido respuesta");
				    }
				    
					// Cerramos tanto la entrada del usuario como el socket
				    escanear.close();
					socketCliente.close();
					
				}
					
				} while (!entradaUsuario.equals("salir"));
			} catch (Exception e) {
				System.out.println("¡Hasta la próxima!");
			}
	}

}
